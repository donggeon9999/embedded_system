package com.example.final_project;

public class instru {
	public String ins;
	public String img;
	public instru(String ins, String img)
	{
		this.ins = ins;
		this.img = img;
	}
	public String getins()
	{
		return ins;
	}
	public String getimg()
	{
		return img;
	}
}
