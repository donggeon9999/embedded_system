package com.example.final_project;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	private RadioGroup activityRadioGroup;
	int food_type_int;
	String food_type_string;
	String food_cnt;
	public int result;
	public TextView mPutTextView;
//	MediaPlayer mp1;
	
	public native int Display_Select(int ch,String str);
	
	static {
		System.loadLibrary("jni_lib");
		};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		activityRadioGroup = (RadioGroup)findViewById(R.id.radioGroup1);
//		mp1 = MediaPlayer.create(this, R.raw.queencard);
        activityRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
            	String getString = new String();
                RadioButton checkedRadioButton = (RadioButton)findViewById(checkedId);
                String selectedActivity = checkedRadioButton.getText().toString();
                // Perform actions based on the selected activity
                // For example, you can display a toast message with the selected activity:
                
                food_type_int = selectedActivity.charAt(0) - '0';
                food_type_string = selectedActivity;
                Toast.makeText(MainActivity.this, "Selected Activity: " + selectedActivity, Toast.LENGTH_SHORT).show();
                Log.d("122", "holylkykl");
                
    			result=Display_Select(food_type_int,food_type_string);
    			Log.d("122", "22222");
	    			switch(result) {
	    				case -1 :
	    					getString = "Device Open Error!";
	    					break;
	    				case 0 :
	    					getString = "OK";
	    					break;
	    				case 1 :
	    					getString = "Check number in Textbox.";
	    			}
    			
            }
        });
	}



 public void btn_Click(View view)
    {
	 	Log.d("test", "Click Start Button");
//	 	mp1.start();
        TextView textView = (TextView)findViewById(R.id.submit);
        EditText editText = (EditText)findViewById(R.id.editText1);
        food_cnt = editText.getText().toString();
        textView.setText(editText.getText());
        Intent intent = new Intent(MainActivity.this, SubActivity.class); 
        intent.putExtra("idx",food_type_int);
        startActivity(intent); 
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
