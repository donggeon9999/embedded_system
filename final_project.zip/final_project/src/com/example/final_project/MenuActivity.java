package com.example.final_project;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MenuActivity extends Activity {
	public TextView manual1;
	public TextView manual2;
	public TextView manual3;
	public TextView title;
	public ImageView img1;
	public ImageView img2;
	public ImageView img3;
	public ImageView img4;
	MediaPlayer mp1;
	int type;
	int menu_idx;
	public native int stopwatch();
	public native int stop_motor();
	public native int timer(int min, int sec);

		void image_set(){
			if(type == 1)
			{
				if(menu_idx == 1){
					img1.setImageResource(R.drawable.img1_1);
					img2.setImageResource(R.drawable.img1_1_1);
					img3.setImageResource(R.drawable.img1_1_2);
					img4.setImageResource(R.drawable.img1_1_3);
					
				}
//				else if (menu_idx == 2){
//					img1.setImageResource(R.drawable.img1_2);
//					img2.setImageResource(R.drawable.img1_2_1);
//					img3.setImageResource(R.drawable.img1_2_2);
//					img4.setImageResource(R.drawable.img1_2_3);
//					
//				}
//				else if (menu_idx == 3){
//					img1.setImageResource(R.drawable.img1_3);
//					img2.setImageResource(R.drawable.img1_3_1);
//					img3.setImageResource(R.drawable.img1_3_2);
//					img4.setImageResource(R.drawable.img1_3_3);
//				}
				
			}
//			if(type == 2)
//			{
//				if(menu_idx == 1){
//					img1.setImageResource(R.drawable.img2_1);
//					img2.setImageResource(R.drawable.img2_1_1);
//					img3.setImageResource(R.drawable.img2_1_2);
//					img4.setImageResource(R.drawable.img2_1_3);
//					
//				}
//				else if (menu_idx == 2){
//					img1.setImageResource(R.drawable.img2_2);
//					img2.setImageResource(R.drawable.img2_2_1);
//					img3.setImageResource(R.drawable.img2_2_2);
//					img4.setImageResource(R.drawable.img2_2_3);
//					
//				}
//				else if (menu_idx == 3){
//					img1.setImageResource(R.drawable.img2_3);
//					img2.setImageResource(R.drawable.img2_3_1);
//					img3.setImageResource(R.drawable.img2_3_2);
//					img4.setImageResource(R.drawable.img2_3_3);
//				}
//				
//			}
			if(type == 3)
			{
				if(menu_idx == 1){
					img1.setImageResource(R.drawable.img3_1);
					img2.setImageResource(R.drawable.img3_1_1);
					img3.setImageResource(R.drawable.img3_1_2);
					img4.setImageResource(R.drawable.img3_1_3);
					
				}
				else if (menu_idx == 2){
					img1.setImageResource(R.drawable.img3_2);
					img2.setImageResource(R.drawable.img3_2_1);
					img3.setImageResource(R.drawable.img3_2_2);
					img4.setImageResource(R.drawable.img3_2_3);
					
				}
				else if (menu_idx == 3){
					img1.setImageResource(R.drawable.img3_3);
					img2.setImageResource(R.drawable.img3_3_1);
					img3.setImageResource(R.drawable.img3_3_2);
					img4.setImageResource(R.drawable.img3_3_3);
				}
				
			}
//			if(type == 4)
//			{
//				if(menu_idx == 1){
//					img1.setImageResource(R.drawable.img4_1);
//					img2.setImageResource(R.drawable.img4_1_1);
//					img3.setImageResource(R.drawable.img4_1_2);
//					img4.setImageResource(R.drawable.img4_1_3);
//					
//				}
//				else if (menu_idx == 2){
//					img1.setImageResource(R.drawable.img4_2);
//					img2.setImageResource(R.drawable.img4_2_1);
//					img3.setImageResource(R.drawable.img4_2_2);
//					img4.setImageResource(R.drawable.img4_2_3);
//					
//				}
//				else if (menu_idx == 3){
//					img1.setImageResource(R.drawable.img4_3);
//					img2.setImageResource(R.drawable.img4_3_1);
//					img3.setImageResource(R.drawable.img4_3_2);
//					img4.setImageResource(R.drawable.img4_3_3);
//				}
//				
//			}
			//img1.setImageResource(R.drawable.img3_2);
			
			
		}
	    @Override
	    protected void onCreate(Bundle savedInstanceState) {
	    	Log.d("holy", "oncreate  Start Button");
	    	super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_menu);
	        Log.d("holy", "oncreate  Start Button");
//	        setContentView(R.layout.recipe);
	        Intent intent = getIntent();
			 menu_idx = intent.getExtras().getInt("idx");
			type = intent.getExtras().getInt("type");
			recipe r1 = ((SubActivity)SubActivity.context_main).get_recipe(menu_idx-1);
	        manual1 = (TextView)findViewById(R.id.manual6);
	        manual2 = (TextView)findViewById(R.id.manual2);
	        manual3 = (TextView)findViewById(R.id.manual3);
	        manual1.setText(r1.getInstructions()[0].getins());
	        manual2.setText(r1.getInstructions()[1].getins());
	        manual3.setText(r1.getInstructions()[2].getins());
	        
	        img1 = (ImageView)findViewById(R.id.imageView1);
	        img2 = (ImageView)findViewById(R.id.imageView2);
	        img3 = (ImageView)findViewById(R.id.imageView3);
	        img4 = (ImageView)findViewById(R.id.imageView4);
	        mp1 = MediaPlayer.create(this, R.raw.queencard);
	        image_set();
	        title = (TextView)findViewById(R.id.title);
	        title.setText(r1.getTitle());
	    }
    public void btn_Click_timer(View view)
    {
    	
	 	mp1.start();
    	Log.d("test", "Click Start timer Button1");
    	EditText min = (EditText)findViewById(R.id.editText1);
    	EditText sec = (EditText)findViewById(R.id.editText2);
    	int m = Integer.valueOf(min.getText().toString());
    	int s = Integer.valueOf(sec.getText().toString());
    	Log.d("test", min.getText().toString());
    	int ret = timer(m,s);
    	
    	
    }
    public void btn_Click_stop_motor(View view)
    {
    	mp1.stop();
    	Log.d("test", "Click Start timer Button1");
    	int ret = stop_motor();
    	
    	
    }
    public void btn_Click_stopwatch(View view)
    {
    	mp1.start();
    	Log.d("test", "Click Start timer Button1");
        int ret = stopwatch();
    }
    
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
