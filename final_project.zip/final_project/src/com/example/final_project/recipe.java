package com.example.final_project;

public class recipe {
	private String title;
    private String ingredients;
    private instru[] instructions;
    private int inst_cnt, calories;
    private String img_url ;
    private String tips ;
    public recipe(String title, String ingredients,String img,String tips,int calories,int inst_cnt, instru... s ) {
        this.title = title;
        this.img_url = img;
        this.ingredients = ingredients;
        this.instructions = s;
        this.inst_cnt = inst_cnt;
        this.calories = calories;
        this.tips = tips;
    }
    public int getCalories(){
    	return calories;
    }
    public String getTitle() {
        return title;
    }
    public String gettips() {
        return tips;
    }

    public int getcal() {
        return calories;
    }
    public String getimg() {
        return img_url;
    }
    public String getIngredients() {
        return ingredients;
    }

    public instru[] getInstructions() {
        return instructions;
    }
    public int getInsCnt(){
    	return inst_cnt;
    }
}
