package com.example.final_project;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;



public class SubActivity extends Activity{
	LinearLayout ll;
    TextView tv;
    Button btn;
    private List<recipe> recipeList;
    public static Context context_main;
    int menu_idx ;

	recipe get_recipe(int idx){
		return recipeList.get(idx);
	}
	private static String getTagValue(String tag, Element eElement) {
	    NodeList nlList = eElement.getElementsByTagName(tag).item(0).getChildNodes();
	    Node nValue = (Node) nlList.item(0);
	    if(nValue == null) 
	        return null;
	    return nValue.getNodeValue();
	}
	
	void create_list() throws ParserConfigurationException, SAXException, IOException{
		Log.d("te11111st", "parsing");
		recipeList = new ArrayList<recipe>();
		
		Intent intent = getIntent();
		menu_idx = intent.getExtras().getInt("idx");
		Log.d("te11111st", "ssd");
		if(menu_idx == 1){
			Log.d("te11111st", "11111");
			recipeList.add(new recipe("새우아욱죽","귀리밥 100g, 아욱 30g, 건새우 25g, 칵테일새우 25g, 저염 된장 30g", 
	        		"http://www.foodsafetykorea.go.kr/uploadimg/cook/10_00028_1.png","일반 된장 보다 염도를 낮춘 저염된장을 사용하고 칼륨의 함량이 높은 아욱을 넣어 나트륨 배출을 돕는다.",201,3, 
	        		new instru("1. 저염 된장을 물 300cc에 풀어준 뒤 건새우를담가 30분 정도 담가준 뒤 살짝 끓여준다.","http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00028_1.png"),
	        		new instru("2. 새우를 풀어준 된장 물을 체에 걸러준다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00028_2.png"),
	        		new instru("3. 아욱은 뜨거운 물에 데쳐서 먹기 좋게 썬다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00028_3.png")
	        		));
	        recipeList.add(new recipe("소고기리조또롤","쌀(50g), 강황가루(20g), 버터(10g)마늘(10g), 양파(20g), 새송이(30g), 파프리카(30g)소고기(150g), 소금(0.1g), 후춧가루(0.02g)하얀된장(10g), 생크림(20g), 육수(200g)", 
	        		"http://www.foodsafetykorea.go.kr/uploadimg/cook/10_00029_1.png","장에 생크림을 섞어 풍미는 높이고 나트륨 함량은 낮췄어요.",215,3, 
	        		new instru("1. 쌀은 불려 놓고, 마늘은 작게 다지고,양파는 새송이와 파프리카와 함께입자를 크게 다져 준비한다.","http://www.foodsafetykorea.go.kr/uploadimg/20230206/20230206054820_1675673300714.jpg"),
	        		new instru("2. 소고기는 포를 넓게 떠서 소금과후춧가루를 뿌려 밑간을 해 놓는다.", "http://www.foodsafetykorea.go.kr/uploadimg/20230206/20230206054834_1675673314720.jpg"),
	        		new instru("3. 냄비에 버터를 넣고, 마늘과 양파를먼저 볶다가, 새송이와 파프리카를넣는다.", "http://www.foodsafetykorea.go.kr/uploadimg/20230206/20230206054908_1675673348152.jpg")
	        		)); 
	        recipeList.add(new recipe("방울토마토 소박이","●방울토마토 소박이 : 방울토마토 150g(5개), 양파 10g(3×1cm), 부추 10g(5줄기)●양념장 : 고춧가루 4g(1작은술), 멸치액젓 3g(2/3작은술), 다진 마늘 2.5g(1/2쪽), 매실액 2g(1/3작은술), 설탕 2g(1/3작은술), 물 2ml(1/3작은술), 통깨 약간", 
	        		"http://www.foodsafetykorea.go.kr/uploadimg/cook/10_00031_1.png","소금에 절이는 오이 대신 방울토마토를 사용하여 나트륨 섭취를 줄였어요. 토마토에는 과일에 대체로 없는 글루탐산이 풍부하여 감칠맛을 내주며, 겉절이 양념과 잘 어우러져 상큼함과 감칠맛을 내주어요.",
	        		45,3, 
	        		new instru("1. 물기를 빼고 2cm 정도의 크기로 썰은 부추와 양파를 양념장에 섞어 양념속을 만든다.","http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00031_1.png"),
	        		new instru("2. 깨끗이 씻은 방울토마토는 꼭지를 떼고 윗부분에 칼로 십자모양으로 칼집을 낸다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00031_4.png"),
	        		new instru("3. 칼집을 낸 방울토마토에 양념속을 사이사이에 넣어 버무린다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00031_5.png")
	        		));
			}
		if(menu_idx == 2){
			Log.d("te11111st", "22222");
			recipeList.add(new recipe("저염 된장으로 맛을 낸 황태해장국","새우두부계란찜연두부 75g(3/4모), 칵테일새우 20g(5마리), 달걀 30g(1/2개), 생크림 13g(1큰술), 설탕 5g(1작은술), 무염버터 5g(1작은술)고명시금치 10g(3줄기)", 
	        		"http://www.foodsafetykorea.go.kr/uploadimg/cook/10_00028_1.png","나트륨의 배출을 도와주는 것으로 알려진 칼륨이 풍부한 시금치와 소금, 간장 등의 양념 대신 새우에 들어있는 간으로 맛을 내요.",220,3, 
	        		new instru("1. 손질된 새우를 끓는 물에 데쳐 건진다.","http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00028_1.png"),
	        		new instru("2. 연두부, 달걀, 생크림, 설탕에 녹인 무염버터를 믹서에 넣고 간 뒤 새우(1)를 함께 섞어 그릇에 담는다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00028_2.png"),
	        		new instru("3. 시금치를 잘게 다져 혼합물 그릇(2)에 뿌리고 찜기에 넣고 중간 불에서 10분 정도 찐다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00028_3.png")
	        		));
	        recipeList.add(new recipe("부추 콩가루 찜","[1인분]조선부추 50g, 날콩가루 7g(1⅓작은술)·양념장 : 저염간장 3g(2/3작은술), 다진 대파 5g(1작은술), 다진 마늘 2g(1/2쪽), 고춧가루 2g(1/3작은술), 요리당 2g(1/3작은술), 참기름 2g(1/3작은술), 참깨 약간", 
	        		"http://www.foodsafetykorea.go.kr/uploadimg/cook/10_00029_1.png","콩가루로 버무려 감칠맛과 고소한 맛으로 나트륨 사용량을 줄여보세요. 부추는 피를 맑게 하고 허약 체질을 개선하여 성인병을 예방하는데 효과가 있지만, 알레르기 체질이나 위장이 약한 사람은 부작용이 생길 수 있으니 주의하세요.",215,3, 
	        		new instru("1. 부추는 깨끗이 씻어 물기를 제거하고, 5cm 길이로 썰고 부추에 날콩가루를 넣고 고루 섞이도록 버무린다.","http://www.foodsafetykorea.go.kr/uploadimg/20230206/20230206054820_1675673300714.jpg"),
	        		new instru("2. 찜기에 면보를 깔고 부추를 넣은 후 김이 오르게 쪄서 파랗게 익힌다.", "http://www.foodsafetykorea.go.kr/uploadimg/20230206/20230206054834_1675673314720.jpg"),
	        		new instru("3. 저염간장에 다진 대파, 다진 마늘, 고춧가루, 요리당 , 참기름, 참깨를 섞어 양념장을 만들고 찐 부추는 그릇에 담아낸다.", "http://www.foodsafetykorea.go.kr/uploadimg/20230206/20230206054908_1675673348152.jpg")
	        		)); 
	        recipeList.add(new recipe("방울토마토 소박이","●방울토마토 소박이 : 방울토마토 150g(5개), 양파 10g(3×1cm), 부추 10g(5줄기)●양념장 : 고춧가루 4g(1작은술), 멸치액젓 3g(2/3작은술), 다진 마늘 2.5g(1/2쪽), 매실액 2g(1/3작은술), 설탕 2g(1/3작은술), 물 2ml(1/3작은술), 통깨 약간", 
	        		"http://www.foodsafetykorea.go.kr/uploadimg/cook/10_00031_1.png","소금에 절이는 오이 대신 방울토마토를 사용하여 나트륨 섭취를 줄였어요. 토마토에는 과일에 대체로 없는 글루탐산이 풍부하여 감칠맛을 내주며, 겉절이 양념과 잘 어우러져 상큼함과 감칠맛을 내주어요.",
	        		45,3, 
	        		new instru("1. 물기를 빼고 2cm 정도의 크기로 썰은 부추와 양파를 양념장에 섞어 양념속을 만든다.","http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00031_1.png"),
	        		new instru("2. 깨끗이 씻은 방울토마토는 꼭지를 떼고 윗부분에 칼로 십자모양으로 칼집을 낸다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00031_4.png"),
	        		new instru("3. 칼집을 낸 방울토마토에 양념속을 사이사이에 넣어 버무린다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00031_5.png")
	        		));
			}
		if(menu_idx == 3){
			Log.d("te11111st", "3333");
        recipeList.add(new recipe("새우 두부 계란찜","새우두부계란찜연두부 75g(3/4모), 칵테일새우 20g(5마리), 달걀 30g(1/2개), 생크림 13g(1큰술), 설탕 5g(1작은술), 무염버터 5g(1작은술)고명시금치 10g(3줄기)", 
        		"http://www.foodsafetykorea.go.kr/uploadimg/cook/10_00028_1.png","나트륨의 배출을 도와주는 것으로 알려진 칼륨이 풍부한 시금치와 소금, 간장 등의 양념 대신 새우에 들어있는 간으로 맛을 내요.",220,3, 
        		new instru("1. 손질된 새우를 끓는 물에 데쳐 건진다.","http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00028_1.png"),
        		new instru("2. 연두부, 달걀, 생크림, 설탕에 녹인 무염버터를 믹서에 넣고 간 뒤 새우(1)를 함께 섞어 그릇에 담는다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00028_2.png"),
        		new instru("3. 시금치를 잘게 다져 혼합물 그릇(2)에 뿌리고 찜기에 넣고 중간 불에서 10분 정도 찐다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00028_3.png")
        		));
        recipeList.add(new recipe("부추 콩가루 찜","[1인분]조선부추 50g, 날콩가루 7g(1⅓작은술)·양념장 : 저염간장 3g(2/3작은술), 다진 대파 5g(1작은술), 다진 마늘 2g(1/2쪽), 고춧가루 2g(1/3작은술), 요리당 2g(1/3작은술), 참기름 2g(1/3작은술), 참깨 약간", 
        		"http://www.foodsafetykorea.go.kr/uploadimg/cook/10_00029_1.png","콩가루로 버무려 감칠맛과 고소한 맛으로 나트륨 사용량을 줄여보세요. 부추는 피를 맑게 하고 허약 체질을 개선하여 성인병을 예방하는데 효과가 있지만, 알레르기 체질이나 위장이 약한 사람은 부작용이 생길 수 있으니 주의하세요.",215,3, 
        		new instru("1. 부추는 깨끗이 씻어 물기를 제거하고, 5cm 길이로 썰고 부추에 날콩가루를 넣고 고루 섞이도록 버무린다.","http://www.foodsafetykorea.go.kr/uploadimg/20230206/20230206054820_1675673300714.jpg"),
        		new instru("2. 찜기에 면보를 깔고 부추를 넣은 후 김이 오르게 쪄서 파랗게 익힌다.", "http://www.foodsafetykorea.go.kr/uploadimg/20230206/20230206054834_1675673314720.jpg"),
        		new instru("3. 저염간장에 다진 대파, 다진 마늘, 고춧가루, 요리당 , 참기름, 참깨를 섞어 양념장을 만들고 찐 부추는 그릇에 담아낸다.", "http://www.foodsafetykorea.go.kr/uploadimg/20230206/20230206054908_1675673348152.jpg")
        		)); 
        recipeList.add(new recipe("방울토마토 소박이","●방울토마토 소박이 : 방울토마토 150g(5개), 양파 10g(3×1cm), 부추 10g(5줄기)●양념장 : 고춧가루 4g(1작은술), 멸치액젓 3g(2/3작은술), 다진 마늘 2.5g(1/2쪽), 매실액 2g(1/3작은술), 설탕 2g(1/3작은술), 물 2ml(1/3작은술), 통깨 약간", 
        		"http://www.foodsafetykorea.go.kr/uploadimg/cook/10_00031_1.png","소금에 절이는 오이 대신 방울토마토를 사용하여 나트륨 섭취를 줄였어요. 토마토에는 과일에 대체로 없는 글루탐산이 풍부하여 감칠맛을 내주며, 겉절이 양념과 잘 어우러져 상큼함과 감칠맛을 내주어요.",
        		45,3, 
        		new instru("1. 물기를 빼고 2cm 정도의 크기로 썰은 부추와 양파를 양념장에 섞어 양념속을 만든다.","http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00031_1.png"),
        		new instru("2. 깨끗이 씻은 방울토마토는 꼭지를 떼고 윗부분에 칼로 십자모양으로 칼집을 낸다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00031_4.png"),
        		new instru("3. 칼집을 낸 방울토마토에 양념속을 사이사이에 넣어 버무린다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00031_5.png")
        		));
		}
		if(menu_idx == 4){
			recipeList.add(new recipe("새우 두부 계란찜","새우두부계란찜연두부 75g(3/4모), 칵테일새우 20g(5마리), 달걀 30g(1/2개), 생크림 13g(1큰술), 설탕 5g(1작은술), 무염버터 5g(1작은술)고명시금치 10g(3줄기)", 
	        		"http://www.foodsafetykorea.go.kr/uploadimg/cook/10_00028_1.png","나트륨의 배출을 도와주는 것으로 알려진 칼륨이 풍부한 시금치와 소금, 간장 등의 양념 대신 새우에 들어있는 간으로 맛을 내요.",220,3, 
	        		new instru("1. 손질된 새우를 끓는 물에 데쳐 건진다.","http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00028_1.png"),
	        		new instru("2. 연두부, 달걀, 생크림, 설탕에 녹인 무염버터를 믹서에 넣고 간 뒤 새우(1)를 함께 섞어 그릇에 담는다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00028_2.png"),
	        		new instru("3. 시금치를 잘게 다져 혼합물 그릇(2)에 뿌리고 찜기에 넣고 중간 불에서 10분 정도 찐다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00028_3.png")
	        		));
	        recipeList.add(new recipe("부추 콩가루 찜","[1인분]조선부추 50g, 날콩가루 7g(1⅓작은술)·양념장 : 저염간장 3g(2/3작은술), 다진 대파 5g(1작은술), 다진 마늘 2g(1/2쪽), 고춧가루 2g(1/3작은술), 요리당 2g(1/3작은술), 참기름 2g(1/3작은술), 참깨 약간", 
	        		"http://www.foodsafetykorea.go.kr/uploadimg/cook/10_00029_1.png","콩가루로 버무려 감칠맛과 고소한 맛으로 나트륨 사용량을 줄여보세요. 부추는 피를 맑게 하고 허약 체질을 개선하여 성인병을 예방하는데 효과가 있지만, 알레르기 체질이나 위장이 약한 사람은 부작용이 생길 수 있으니 주의하세요.",215,3, 
	        		new instru("1. 부추는 깨끗이 씻어 물기를 제거하고, 5cm 길이로 썰고 부추에 날콩가루를 넣고 고루 섞이도록 버무린다.","http://www.foodsafetykorea.go.kr/uploadimg/20230206/20230206054820_1675673300714.jpg"),
	        		new instru("2. 찜기에 면보를 깔고 부추를 넣은 후 김이 오르게 쪄서 파랗게 익힌다.", "http://www.foodsafetykorea.go.kr/uploadimg/20230206/20230206054834_1675673314720.jpg"),
	        		new instru("3. 저염간장에 다진 대파, 다진 마늘, 고춧가루, 요리당 , 참기름, 참깨를 섞어 양념장을 만들고 찐 부추는 그릇에 담아낸다.", "http://www.foodsafetykorea.go.kr/uploadimg/20230206/20230206054908_1675673348152.jpg")
	        		)); 
	        recipeList.add(new recipe("방울토마토 소박이","●방울토마토 소박이 : 방울토마토 150g(5개), 양파 10g(3×1cm), 부추 10g(5줄기)●양념장 : 고춧가루 4g(1작은술), 멸치액젓 3g(2/3작은술), 다진 마늘 2.5g(1/2쪽), 매실액 2g(1/3작은술), 설탕 2g(1/3작은술), 물 2ml(1/3작은술), 통깨 약간", 
	        		"http://www.foodsafetykorea.go.kr/uploadimg/cook/10_00031_1.png","소금에 절이는 오이 대신 방울토마토를 사용하여 나트륨 섭취를 줄였어요. 토마토에는 과일에 대체로 없는 글루탐산이 풍부하여 감칠맛을 내주며, 겉절이 양념과 잘 어우러져 상큼함과 감칠맛을 내주어요.",
	        		45,3, 
	        		new instru("1. 물기를 빼고 2cm 정도의 크기로 썰은 부추와 양파를 양념장에 섞어 양념속을 만든다.","http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00031_1.png"),
	        		new instru("2. 깨끗이 씻은 방울토마토는 꼭지를 떼고 윗부분에 칼로 십자모양으로 칼집을 낸다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00031_4.png"),
	        		new instru("3. 칼집을 낸 방울토마토에 양념속을 사이사이에 넣어 버무린다.", "http://www.foodsafetykorea.go.kr/uploadimg/cook/20_00031_5.png")
	        		));
			}
	}
   
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2);
    	context_main = this;
         try {
			create_list();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			Log.d("te1111331st", e.toString());
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			Log.d("te1111551st", e.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Log.d("te1111661st", e.toString());
		}
        
        recipe r1 =recipeList.get(0); 
        recipe r2 =recipeList.get(1);
        recipe r3 =recipeList.get(2);
//        recipe r4 =recipeList.get(3);
//        recipe r5 =recipeList.get(4);
        		//new recipe("mama","mama",2,"sdfasd","asdfasdf","asdfasdg"); 
        		//((MainActivity)MainAc,tivity.context_main).get_recipe(0);
        
        TextView tv1 = (TextView)findViewById(R.id.menu1);
        tv1.setText(r1.getTitle());
        TextView tv2 = (TextView)findViewById(R.id.menu2);
        tv2.setText(r2.getTitle());
        TextView tv3 = (TextView)findViewById(R.id.menu3);
        tv3.setText(r3.getTitle());
//        TextView tv4 = (TextView)findViewById(R.id.menu4);
//        tv4.setText(r4.getTitle());
//        TextView tv5 = (TextView)findViewById(R.id.menu5);
//        tv5.setText(r5.getTitle());
        Log.d("test", "Service onCreate");
         
    }
    public void btn_Click1(View view)
    {
    	Log.d("test", "Click Start Button1");
        
        Intent intent = new Intent(SubActivity.this, MenuActivity.class); 
        intent.putExtra("idx",1);
        intent.putExtra("type",menu_idx);
        startActivity(intent); 
    }
    public void btn_Click2(View view)
    {
    	Log.d("test", "Click Start Button2");
        
        Intent intent = new Intent(SubActivity.this, MenuActivity.class); 
        Log.d("test", "Click Start Button2");
        intent.putExtra("idx",2);
        intent.putExtra("type",menu_idx);
        Log.d("test", "Click Start Button2");
        startActivity(intent); 
        Log.d("test", "Click Start Button2");
    }
    public void btn_Click3(View view)
    {
    	Log.d("test", "Click Start Button3");
        
        Intent intent = new Intent(SubActivity.this, MenuActivity.class); 
//        Log.d("test", "Click Start Button3");
        intent.putExtra("idx",3);
        intent.putExtra("type",menu_idx);
//        Log.d("test", "Click Start Button3");
        startActivity(intent); 
//        Log.d("test", "Click Start Button3");
    }
    
    

    public void back_btn_Click(View view)
    {
		 finish();
    }
//
//
//    View.OnClickListener myListener = new View.OnClickListener()
//    {
//        @Override
//        public void onClick(View v)
//        {
//            int tvKey = (Integer)v.getTag();
//            switch (tvKey)
//            {
//                case 1 :
//                    Toast.makeText(getApplication(),"첫번째 텍스트뷰",Toast.LENGTH_SHORT).show();
//                    break;
//
//                case 2 :
//                    Toast.makeText(getApplication(),"두번째 텍스트뷰",Toast.LENGTH_SHORT).show();
//                    break;
//
//                case 3 :
//                    Toast.makeText(getApplication(),"세번째 텍스트뷰",Toast.LENGTH_SHORT).show();
//                    break;
//            }
//        }
//    };


    @Override
    public void onDestroy() {
        super.onDestroy();
       
        Log.d("test", "Service onDestroy");
    }
}
