#include <string.h>
#include <jni.h>
#include <android/log.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <linux/ioctl.h>
#include <stdio.h>

#define MAJOR_NUM 242


#define DEVICE_FILE_NAME "stopwatch"
#define DEVICE_PATH "/dev/stopwatch"

#define SELECT 0
#define STOP_WATCH 1
#define TIMER 2

unsigned long *fpga_addr;
unsigned char *led_addr;


unsigned char fpga_number[10][10] = {
{0x3e,0x7f,0x63,0x73,0x73,0x6f,0x67,0x63,0x7f,0x3e}, // 0
{0x0c,0x1c,0x1c,0x0c,0x0c,0x0c,0x0c,0x0c,0x0c,0x1e}, // 1
{0x7e,0x7f,0x03,0x03,0x3f,0x7e,0x60,0x60,0x7f,0x7f}, // 2
{0xfe,0x7f,0x03,0x03,0x7f,0x7f,0x03,0x03,0x7f,0x7e}, // 3
{0x66,0x66,0x66,0x66,0x66,0x66,0x7f,0x7f,0x06,0x06}, // 4
{0x7f,0x7f,0x60,0x60,0x7e,0x7f,0x03,0x03,0x7f,0x7e}, // 5
{0x60,0x60,0x60,0x60,0x7e,0x7f,0x63,0x63,0x7f,0x3e}, // 6
{0x7f,0x7f,0x63,0x63,0x03,0x03,0x03,0x03,0x03,0x03}, // 7
{0x3e,0x7f,0x63,0x63,0x7f,0x7f,0x63,0x63,0x7f,0x3e}, // 8
{0x3e,0x7f,0x63,0x63,0x7f,0x3f,0x03,0x03,0x03,0x03} // 9
};
unsigned char fpga_set_full[10] = {
// memset(array,0x7e,sizeof(array));
0x7f,0x7f,0x7f,0x7f,0x7f,0x7f,0x7f,0x7f,0x7f,0x7f
};
unsigned char fpga_set_blank[10] = {
// memset(array,0x00,sizeof(array));
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

int select_display(int num,char * str)
{
	char buf[2] = {'\0',};
	int fd ;

	fd = open("/dev/stopwatch", O_RDWR);
	if(fd < 0) {
		perror("/dev/stopwatch error");
		exit(-1);
	}
	else { printf("< stopwatch Device has been detected > \n"); }


	buf[0] = '0';
	buf[1] = num +'0';
//	__android_log_print(ANDROID_LOG_INFO, "dev open11 error11", " value = %s", data);
	int retn = write(fd, buf, 2);
//	__android_log_print(ANDROID_LOG_INFO, "dev open11 error22", " value = %s", str);

	close(fd);
	return 0;
}
int stopwatch(void)
{
	int i;
	int fd ;
	int retn;
	char buf[2] = {'2',};
	fd = open("/dev/stopwatch", O_RDWR);
	if(fd < 0) {
		perror("/dev/stopwatch error");
		exit(-1);
	}
	else { printf("< stopwatch Device has been detected > \n"); }

	retn = write(fd, buf, 2);
	close(fd);
	return 0;

}
int stop_motor(void)
{
	int i;
	int fd ;
	int retn;
	char buf[2] = {'3',};
	fd = open("/dev/stopwatch", O_RDWR);
	if(fd < 0) {
		perror("/dev/stopwatch error");
		exit(-1);
	}
	else { printf("< stopwatch Device has been detected > \n"); }

	retn = write(fd, buf, 2);
	close(fd);
	return 0;

}

int timer(int min, int sec)
{int fd ;
	char buf[5] ={'1','0','0','1','0'};
	buf[1] = min / 10 +'0';
	buf[2] = min %10 +'0';
	buf[3] = sec / 10 +'0';
	buf[4] = sec %10 +'0';
	__android_log_print(ANDROID_LOG_INFO, "tiemr value", " value =%d %d",min,sec);
	fd = open("/dev/stopwatch", O_RDWR);
		if(fd < 0) {
			perror("/dev/stopwatch error");
			exit(-1);
		}
	    else { printf("< stopwatch Device has been detected > \n"); }

		int retn = write(fd, buf, 5);
		close(fd);
	    return 0;

}
//int timer_display(int min, int sec){
//
//thiz
//	sprintf(data, %d )
//}
JNIEXPORT jint JNICALL Java_com_example_final_1project_MenuActivity_stop_1motor(JNIEnv* env, jobject thiz)
{

	__android_log_print(ANDROID_LOG_INFO, "FpgaFndExample", " value =sss");
		int ret = stop_motor();
		return ret;
}
JNIEXPORT jint JNICALL Java_com_example_final_1project_MenuActivity_stopwatch(JNIEnv* env, jobject thiz)
{
	__android_log_print(ANDROID_LOG_INFO, "FpgaFndExample", " value =sss");
	int ret = stopwatch();
	return ret;

}

JNIEXPORT jint JNICALL Java_com_example_final_1project_MenuActivity_timer(JNIEnv* env, jobject thiz, jint num1, jint num2){

	__android_log_print(ANDROID_LOG_INFO, "FpgaFndExample", " value =dfwdfwdf");
	int ret = timer(num1,num2);
	return ret;
}

JNIEXPORT jint JNICALL Java_com_example_final_1project_MainActivity_Display_1Select(JNIEnv* env, jobject thiz, jint num, jstring val)
{
	jint result;
	char * pstr1 = (*env)->GetStringUTFChars(env,val,NULL);
	__android_log_print(ANDROID_LOG_INFO, "FpgaFndExample", " value = %s", pstr1);

//	fpga_text_lcd(pstr1," ");
//	fpga_dot(num);
	select_display(num, pstr1);

	return result;
}


